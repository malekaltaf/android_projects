package code.name.monkey.retromusic.transform

import android.view.View
import androidx.viewpager.widget.ViewPager

class DefaultTransformer : ViewPager.PageTransformer {
    override fun transformPage(page: View, position: Float) {}
}