package code.name.monkey.retromusic.lyrics;

/**
 * Desc : 歌词实体 Author : Lauzy Date : 2017/10/13 Blog : http://www.jianshu.com/u/e76853f863a9 Email :
 * freedompaladin@gmail.com
 */
public class Lrc {
  private long time;
  private String text;

  public long getTime() {
    return time;
  }

  public void setTime(long time) {
    this.time = time;
  }

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }
}
