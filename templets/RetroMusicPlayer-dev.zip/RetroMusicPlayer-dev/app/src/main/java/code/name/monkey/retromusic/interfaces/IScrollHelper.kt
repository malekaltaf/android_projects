package code.name.monkey.retromusic.interfaces

interface IScrollHelper {
    fun scrollToTop()
}