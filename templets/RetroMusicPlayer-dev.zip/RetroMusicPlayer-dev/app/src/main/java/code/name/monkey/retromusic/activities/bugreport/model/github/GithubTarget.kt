package code.name.monkey.retromusic.activities.bugreport.model.github

class GithubTarget(val username: String, val repository: String)