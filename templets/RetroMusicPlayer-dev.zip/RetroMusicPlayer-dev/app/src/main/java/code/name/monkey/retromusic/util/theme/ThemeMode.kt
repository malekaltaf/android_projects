package code.name.monkey.retromusic.util.theme

enum class ThemeMode {
    LIGHT,
    DARK,
    BLACK,
    AUTO
}