package code.name.monkey.retromusic.model

import android.graphics.Bitmap

class ArtworkInfo constructor(val albumId: Long, val artwork: Bitmap?)
