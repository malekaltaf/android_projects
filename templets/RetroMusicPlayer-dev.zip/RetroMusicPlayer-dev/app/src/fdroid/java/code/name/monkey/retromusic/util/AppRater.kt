package code.name.monkey.retromusic.util

import android.content.Context

@Suppress("UNUSED_PARAMETER")
object AppRater {
    fun appLaunched(context: Context) {}
}