package code.name.monkey.retromusic.activities.base


abstract class AbsCastActivity : AbsSlidingMusicPanelActivity() {
}