
## ATM MACHINE APP SIMULATOR


## Getting Started

Just clone or download the repository.

### Who can use this project?

The app does not actually dispense cash, it just simulates the process of using the ATM in your android phone. The projects as 2 apps in different module. One is the Bank app that Fetches (GET) the transaction sent for approval from the atm app which POST to the api.

### Tools used for the projects

   [Retrofit] I used retrofit to make network request GET and POST.
   [Firebase] Firebase was user for email and password authenticaion and also Phone Number OPT verification which acted like your secured ATM Pin.
   
 
### GitHub Api Response in JSON

##  App Built by Module (App Modularization)

The app was built using 2 modules. The bank app which is = bankapp module. While bank = atm app. 


## API
 I hosted my data here http://bolsschools.com/db.json
