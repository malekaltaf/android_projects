To run the app use any of the following account number and their respective pin:

Acc no: 1234567890 pin: 1234 <br>Acc no: 1234567891 pin: 4321
<br>it can also be found [here](https://github.com/tobioyelekan/ATM/blob/master/app/src/main/java/com/example/android/atm/db/Customer.kt)

Project uses AndroidX artifacts and Architecture components like:
- DataBinding
- ViewModel and LiveData
- Repository pattern
- Navigation component
- Room database
- Kotlin Coroutine
