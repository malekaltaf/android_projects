package com.example.android.atm.ui.viewmodels

import androidx.lifecycle.ViewModel;

class WithdrawOptionsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
