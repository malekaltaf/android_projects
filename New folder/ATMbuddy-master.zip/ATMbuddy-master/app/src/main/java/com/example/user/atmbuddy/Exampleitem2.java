package com.example.user.atmbuddy;

public class Exampleitem2 {
    String code;
    String address;
    String status;

    public Exampleitem2(String  code, String address, String status) {
        this.code = code;
        this.address = address;
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public String getAddress() {
        return address;
    }

    public String getStatus() {
        return status;
    }
}
