package com.example.user.atmbuddy;

public class Exampleitem3 {
    String code;
    String msg;

    public Exampleitem3(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Exampleitem3() {
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
