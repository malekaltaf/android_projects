# ATM
Android Studio ATM Project

Login Instruction:

Username and PIN Admin :
--------------------------------
Username : admin
PIN : admin

Username and PIN for customers :
--------------------------------
Account #1.
Username : compteUn
PIN : compteUn

Account #2.
Username : compteDeux
PIN : compteDeux

Account #3.
Username : compteTrois
PIN : compteTrois
