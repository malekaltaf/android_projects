package com.briangotti.guichetautomatiqueatm;

import android.app.Application;

public class ConfigurationGuichet extends Application {
    StubsPourSimulation stubsPourSimulation = new StubsPourSimulation();




}
