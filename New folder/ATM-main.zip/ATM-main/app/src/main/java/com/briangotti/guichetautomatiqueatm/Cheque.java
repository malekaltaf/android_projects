package com.briangotti.guichetautomatiqueatm;

public class Cheque extends Compte {
}
