import React from 'react';
import {
  StyleSheet,
  Text,
  View
} from 'react-native';

Loading = () => {
  return(
    <View>
      <Text>
        Loading
      </Text>
    </View>
  );
}

export default Loading;