# android-atm-application
This application simulates the basic functions of an ATM machine. 
Has 2 simulation ATM cards to choose from with the pin 9903 & 3285 respectively.
